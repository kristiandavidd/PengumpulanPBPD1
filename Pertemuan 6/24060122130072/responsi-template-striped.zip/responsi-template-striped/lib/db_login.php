<?php
// TODO 1 : SETUP & CONNECT DATABASE


function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
